from django.apps import AppConfig


class CeleryExplorerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'celery_explorer'
